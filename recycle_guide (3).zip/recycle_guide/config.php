<?php
$host = 'localhost';
$db = 'iwp';
$user = 'root';
$pass = 'master';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
