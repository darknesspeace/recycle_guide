<?php
session_start();
include('config.php');

// Check if the user is logged in, otherwise redirect to login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Fetch user data
$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recycle Guide and Navigator</title>
    <link rel="stylesheet" href="assets/css/c1.css">
</head>

<body>
    <header>
        <div class="recycle-symbol">♻️</div>
        <h1>Recycle Guide and Navigator</h1>
        <div id="positivity-line"></div>
        <br><br>
        <h2>Welcome, <?php echo $user['username']; ?>!</h2>
        <a href="logout.php" class="redirect">Logout</a> <!-- Logout Button -->
    </header>

    <main>
        <!-- Recycling Price Calculator -->
        <section id="price">
            <div class="calc">
                <h1>Recycling Price Calculator</h1>
                <form id="recyclingForm" method="POST" action="">
                    <center>
                        <label for="itemType">Select the type of recycling item:</label>
                        <select id="itemType" name="itemType" required>
                            <option value="plastic">Plastic</option>
                            <option value="paper">Paper</option>
                            <option value="glass">Glass</option>
                            <option value="metal">Metal</option>
                            <option value="electronics">Electronics</option>
                        </select>

                        <label for="quantity"><br><br>Enter quantity (in kg):</label>
                        <input type="number" id="quantity" name="quantity" min="0.1" step="0.1" required><br><br>

                        <button type="submit" name="calculate">Calculate Price</button>
                    </center>
                </form>

                <!-- PHP code to handle price calculation and update recycled amount -->
                <?php
                if (isset($_POST['calculate'])) {
                    $material = $_POST['itemType'];
                    $quantity = $_POST['quantity'];
                    $price = 0;

                    // Define the price for each material
                    switch ($material) {
                        case 'plastic':
                            $price = 1;
                            break;
                        case 'metal':
                            $price = 2;
                            break;
                        case 'glass':
                            $price = 0.5;
                            break;
                        case 'electronics':
                            $price = 1.5;
                            break;
                        case 'paper':
                            $price = 0.75;
                            break;
                    }

                    // Calculate total price
                    $total = $price * $quantity;
                    echo "<p>Total Price: $" . number_format($total, 2) . "</p>";

                    // Update user's total recycled amount in the database
                    $conn->query("UPDATE users SET recycled = recycled + $quantity WHERE id = $user_id");

                    // Fetch updated leaderboard after updating the user's recycled amount
                    $leaderboard_result = $conn->query("SELECT username, recycled FROM users ORDER BY recycled DESC LIMIT 5");
                }
                ?>
            </div>
        </section>

        <!-- Leaderboard Section -->
        <section id="leaderboard">
            <h2>Top Recyclers</h2>
            <div id="leaderboardTable">
                <table>
                    <thead>
                        <tr>
                            <th>Rank</th>
                            <th>Username</th>
                            <th>Recycled (Kg)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($leaderboard_result)) {
                            $rank = 1;
                            while ($row = $leaderboard_result->fetch_assoc()) {
                                echo "<tr>
                                        <td>" . $rank . "</td>
                                        <td>" . $row['username'] . "</td>
                                        <td>" . $row['recycled'] . "</td>
                                      </tr>";
                                $rank++;
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2024 Recycle Guide. All rights reserved.</p>
            <nav>
                <ul>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="contact.html">Contact Us</a></li>
                    <li><a href="#">Services</a></li>
                </ul>
            </nav>
        </div>
    </footer>

</body>
</html>
