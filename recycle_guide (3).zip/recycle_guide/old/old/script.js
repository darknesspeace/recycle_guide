let currentSlide = 0;

function moveSlide(direction) {
    const slides = document.querySelectorAll('.slide_div');
    const totalSlides = slides.length;
    currentSlide = (currentSlide + direction + totalSlides) % totalSlides;
    const offset = -currentSlide * 100; // Adjust this value if necessary
    document.getElementById('imgContainer').style.transform = 'translateX(' + offset + '%)';
}



const messages = [
  "Recycling: It's good for the planet!",
  "Every recycled item makes a difference.",
  "Choose to recycle, choose a better future.",
  "Together, let's reduce waste and make a change.",
  "Recycling is easy, make it a habit!"
];

function updateMessage() {
    const positivityLine = document.getElementById('positivity-line');

    // Fade out the current message
    positivityLine.classList.add('fade-out');

    // After the fade-out, change the message and fade it back in
    setTimeout(() => {
        const message = messages[Math.floor(Math.random() * messages.length)];
        positivityLine.textContent = message;
        positivityLine.classList.remove('fade-out');
        positivityLine.classList.add('fade-in');
    }, 1000); // Match this timeout to the CSS animation duration

    // Remove the fade-in class after the animation duration to reset for the next cycle
    setTimeout(() => {
        positivityLine.classList.remove('fade-in');
    }, 2000); // Match this timeout to the CSS animation duration

    // Call the function again after 5 seconds to continue the cycle
    setTimeout(updateMessage, 5000);
}

// Initial call to set the first message
updateMessage();





function findRecyclingCenter() {
    const location = document.getElementById('location').value;
    const results = document.getElementById('results');

    if (location) {
        // Dummy data for demonstration
        const recyclingCenters = [
            { name: "Center 1", address: "123 Main St" },
            { name: "Center 2", address: "456 Elm St" }
        ];

        results.innerHTML = '<h3>Recycling Centers near ' + location + ':</h3>';
        const list = document.createElement('ul');

        recyclingCenters.forEach(center => {
            const item = document.createElement('li');
            item.textContent = `${center.name} - ${center.address}`;
            list.appendChild(item);
        });

        results.appendChild(list);
    } else {
        results.innerHTML = '<p>Please enter a location.</p>';
    }
}
function calculatePrice() {
    const itemType = document.getElementById('itemType').value;
    const quantity = parseFloat(document.getElementById('quantity').value);

    let pricePerKg;

    switch (itemType) {
        case 'plastic':
            pricePerKg = 10; // Example price per kg for plastic
            break;
        case 'paper':
            pricePerKg = 5; // Example price per kg for paper
            break;
        case 'glass':
            pricePerKg = 8; // Example price per kg for glass
            break;
        case 'metal':
            pricePerKg = 15; // Example price per kg for metal
            break;
        default:
            pricePerKg = 0;
    }

    const totalPrice = pricePerKg * quantity;

    const resultDiv = document.getElementById('result');
    resultDiv.innerHTML = `Total Price: ₹${totalPrice.toFixed(2)}`;

    const appreciationDiv = document.getElementById('appreciation');
    appreciationDiv.innerHTML = "Thank you for recycling and helping the environment!";
}