CREATE DATABASE recycle_guide_navigator;

USE recycle_guide_navigator;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    total_recycled FLOAT DEFAULT 0,
    reward_points INT DEFAULT 0
);

CREATE TABLE recycling_records (
    record_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    item_type VARCHAR(50),
    quantity FLOAT,
    price FLOAT,
    points_awarded INT,
    recycled_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
